<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServerName = "localhost";
	$MyUserName = "root";
	$MyPassword = "";

	//Database
	$MyDBName = 'osfa_db';

	//Start Connection
	$MyConnection = mysqli_connect($MyServer, $MyUserName, $MyPassword, $MyDBName);

	$num = $_GET['num'];
	$type = $_GET['type'];
	$sem = $_GET['sem'];
	$year = $_GET['year'];
	$added = $_GET['added'];
	
	mysqli_query($MyConnection, "DELETE FROM STUDENT where (STUDENT.STUD_NUM = '$num' AND STUDENT.LOAN_TYPE = '$type' AND STUDENT.LOAN_YEAR = '$year' AND STUDENT.LOAN_SEM = '$sem' AND STUDENT.DATE_ADDED = '$added')");
	
	//mysqli_query($MyConnection, "DELETE FROM BAL_HIST where (STUDENT.STUD_NUM = '$num' AND STUDENT.LOAN_TYPE = '$type' AND STUDENT.LOAN_YEAR = '$year' AND STUDENT.LOAN_SEM = '$sem'");
	
	header("Location: list.php?type=$type");
?>