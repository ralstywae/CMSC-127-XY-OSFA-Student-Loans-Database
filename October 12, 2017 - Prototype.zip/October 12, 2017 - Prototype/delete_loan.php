<?php

	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServer = '';
	$MyUserName = '';
	$MyPassword = '';
	$MyDBName = '';

	//Start Connection
	$MyConnection = mysql_connect($MyServer, $MyUserName, $MyPassword);

	//Select Database
	mysql_select_db($MyDBName,$MyConnection);
	
	$type = $_GET['type'];

	mysql_query("DELETE FROM LOAN_LIST WHERE LOAN_TYPE = '$type'");

	header("Location: index.php?id=$type");
?>