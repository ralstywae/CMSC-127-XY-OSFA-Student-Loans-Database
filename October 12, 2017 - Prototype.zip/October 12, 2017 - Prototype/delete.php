<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServer = '';
	$MyUserName = '';
	$MyPassword = '';
	$MyDBName = '';

	//Start Connection
	$MyConnection = mysql_connect($MyServer, $MyUserName, $MyPassword);

	//Select Database
	mysql_select_db($MyDBName,$MyConnection);

	$num=$_GET['id'];
	$type=$_GET['type'];
	
	mysql_query("DELETE FROM STUDENT where STUD_NUM = '$num' AND LOAN_TYPE = '$type'");
	
	header("Location: list.php?id=$type");
?>