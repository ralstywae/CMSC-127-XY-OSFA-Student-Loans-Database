<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServerName = "localhost";
	$MyUserName = "root";
	$MyPassword = "";

	//Database
	$MyDBName = 'osfa_db';

	//Start Connection
	$MyConnection = mysqli_connect($MyServer, $MyUserName, $MyPassword, $MyDBName);

	$num = $_GET['num'];
	$name = $_GET['name'];
	$type = $_GET['type'];

	$query = "SELECT * FROM STUDENT where STUD_NUM = '$num'";
    while($result = mysqli_fetch_object($MyConnection, $query))
    {
    	$sname = $result->STUD_NAME;
		$snum = $result->STUD_NUM;
		$sex = $result->STUD_SEX;
		$address = $result->STUD_ADDRESS;
		$college = $result->STUD_COLLEGE;
		$year = $result->STUD_YEAR;
		$course = $result->STUD_COURSE;
		$contact = $result->STUD_CONTACT;
		$email = $result->STUD_EMAIL;
		$type = $result->LOAN_TYPE;
		$acadyear = $result->LOAN_YEAR;
		$sem = $result->LOAN_SEM;
		$amt_borrowed = $result->LOAN_AMOUNT;
		$reason = $result->REASON;
    }

    if($_POST['save']){
        $nsname = $_POST['sname'];
        $nsnum = $_POST['snum'];
        $nsex = $_POST['sex'];
        $naddress = $_POST['address'];
        $ncollege = $_POST['college'];
        $nyear = $_POST['year'];
        $ncourse = $_POST['course'];
        $ncontact = $_POST['contact'];
        $nemail = $_POST['email'];
        $ntype = $_POST['type'];
        $nacadyear = $_POST['acadyear'];
        $nsem = $_POST['sem'];
        $namt_borrowed = $_POST['amt_borrowed'];
        $nreason = $_POST['reason'];

        mysqli_query($MyConnection, "UPDATE STUDENT SET STUD_NAME = '$nsname', STUD_NUM = '$nsnum', STUD_SEX = '$nsex', STUD_ADDRESS = '$naddress', STUD_COLLEGE = '$ncollege', STUD_YEAR = $nyear, STUD_COURSE = '$ncourse', STUD_CONTACT = $ncontact, STUD_EMAIL = '$nemail', LOAN_TYPE = '$ntype', LOAN_YEAR = '$nacadyear', LOAN_SEM = '$nsem', LOAN_AMOUNT = $namt_borrowed WHERE STUD_NUM = '$num' AND LOAN_TYPE = '$type'");

        
		echo "<script>alert('Saved Successfully!');
			location = 'history.php?num=$num&name=$sname';</script>";
    }
	
?>

<!DOCTYPE html>
<html>
	<!-- Head -->
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
		<title>Edit Student Information</title>
	</head>

	<!-- Body -->
	<body>
		<!-- Header -->
		<div class="gradient-overlay text-center bg-secondary p-1">
	    	<div class="container-fluid p-1">
	    		<div class="row">
	    			<div class="col-md-12">
	    				<div class="row">
	    					<div class="col-md-2">
	    						<img class="img-fluid d-block rounded-circle" src="uplogo.png" width="200" height="200">
	    					</div>

	    					<div class="col-md-10">
    							<h1 class="text-white">
				                	<font color="#292b2c" class="text-white">
				                		<i>Office of the Student Financial Assistance<br></i>
				                	</font>
				              	</h1>

              					<h3 class="text-white">
                					<font color="#292b2c" class="text-white">
                						<i>Office of the Director for Student Affairs<br></i>
                					</font>
              					</h3>

              					<h4>
              						<i class="text-center text-white">University of the Philippines - Baguio<br></i>
              					</h4>
              					<h4>
              						<u class="text-center text-white">Student Loans<br></u>
              					</h4>
	    					</div>
	    				</div>
	    			</div>
	    		</div>
	    	</div>
	    </div>

	    <!-- Navigation Bar -->
	    <nav class="navbar navbar-expand-md navbar-dark bg-primary">
	    	<div class="container">

	    		<!-- Logo -->
	    		<a class="navbar-brand" href="index.php">
	    			<b>Home</b>
	    		</a>
	    		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    			<span class="navbar-toggler-icon"></span>
	    		</button>

	    		<!-- Links -->
	    		<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
					<ul class="navbar-nav">
						<li class="nav-item">
							<a class="nav-link" href="search.php"><i class="fa d-inline fa-lg fa-search"></i>Search</a>
						</li>
					</ul>
	       		</div>
	      	</div>
    	</nav>

    	<!-- Addition Form -->
    	<div class="py-5">
  			<div class="container">
    			<div class="row">
      				<div class="col-md-12">
        				<h1>Edit Student Profile</h1>
      				</div>
    			</div>
   				<form class="form-signin" name="myForm" method="POST" enctype="multipart/form-data" name="addroom" onsubmit="return validateForm()">
					<div class="container py-2">
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Student Name</label>
							<div class="col-10 col-md-6">
								<input class="form-control" id="snumber-input" name="sname" required placeholder="Last Name, First Name M.I." value="<?php echo $sname; ?>">
							</div>

							<label for="example-number-input" class="py-2 form-label">Student Number</label>
							<div class="col">
								<input class="form-control" id="snumber-input" name="snum" required pattern ="\d{4}[-]\d{5}" placeholder="XXXX-XXXXX" value="<?php echo $snum; ?>">
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Course</label>
							<div class="col-10 col-md-6">
								<input class="form-control" id="snumber-input" name="course" required placeholder="Undergraduate Degree/Graduate Degree" value="<?php echo $course; ?>">
							</div>
							<label for="example-number-input" class="py-2 col-form-label">College</label>
							<div class="col">
								<input class="form-control" id="snumber-input" name="college" required placeholder="College" value="<?php echo $college; ?>">
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Mailing/Provincial Address</label>
							<div class="col-10 col-md-6">
								<input class="form-control" id="snumber-input" name="address" required placeholder="#69 Example Street, Null City, Nullcline Island" value="<?php echo $address; ?>">
							</div>
							<label for="example-search-input" class="form-label py-2">Sex</label>
							<div class="px-2 py-2">
								<select name="sex" required>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								</select>
							</div>
							<label for="example-number-input" class="form-label py-2">Year</label>
							<div class="px-2 py-2">
								<select name="year">
									<option value = 1>1st Year</option>
									<option value = 2>2nd Year</option>
									<option value = 3>3rd Year</option>
									<option value = 4>4th Year</option>
								</select>
							</div>
						</div>
						<div class="form-group row">
						<label for="example-number-input" class="col-2 col-form-label">E-mail Address</label>
						<div class="col-10 col-md-10">
							<input class="form-control" type="email" id="email-input" name="email" required placeholder="example@some.com" value="<?php echo $email; ?>"> </div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Telephone/Cellphone Number</label>
							<div class="col-10 col-md-10">
								<input class="form-control" id="telnum-input" name="contact" required pattern="\d{,11}" placeholder="Max: 11-Digit #" value="<?php echo $contact; ?>">
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Reason/s</label>
        					<div class="col-10">
        						<textarea class="form-control" id="exampleTextarea" rows="3" name="reason" required pattern = "/^[0-9A-Za-z!@.,;:'"?-]{1,200}\z/" placeholder="200 Characters Only" value="<?php echo $reason; ?>"></textarea>
        					</div>
        				</div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<div class="container">
								<div class="row">
									<div class="col-md-12 center">
										<center>
											<button class="btn" type="submit" name="save" value="save" id="button1" style="background-color: #C0C0C0; width: 150px; height: 60px; padding: 5px"><span>Save</span>
											</button>
										</center>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>

		<!-- Footer -->
        <div class = "text-md-center">
			<p>
				<a href="<?php echo 'list.php?type='.$type.''?>" title = "Let's go back!">&#8617 Go Back to the List</a>
			</p>
		</div>

		<!-- Scripts -->
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    </body>
</html>