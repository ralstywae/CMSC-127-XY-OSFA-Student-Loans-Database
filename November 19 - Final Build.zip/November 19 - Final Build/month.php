<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServerName = "localhost";
	$MyUserName = "root";
	$MyPassword = "";

	//Database
	$MyDBName = 'osfa_db';

	//Create Connection
	$MyConnection = mysqli_connect($MyServerName, $MyUserName, $MyPassword, $MyDBName);

	//Check Connection Status
	if ($MyConnection -> connect_error)
	{
		die("Connection Failed: ". $MyConnection -> connect_error);
	}

	$num = $_GET['num'];
	$name = $_GET['name'];
  	$type = $_GET['type'];	

	$month_name = $_REQUEST['month_name'];
	$year = $_REQUEST['year'];
	$monthWord = date('F', mktime(0, 0, 0, $month_name, 10));
	
	if (isset($month_name) && isset($year))
	{	
		$query = "SELECT * FROM STUDENT WHERE (MONTH(STUDENT.DATE_ADDED) = $month_name AND YEAR(STUDENT.DATE_ADDED) = $year)";

		$MyValues = $MyConnection -> query($query);

		if ($MyValues -> num_rows > 0)
		{
			$count_im = 0;
			$count_radwill = 0;
			$count_safe = 0;
			$count_short = 0;
			$count_tuition = 0;
			$count_upaasv = 0;

			$amount_im = 0;
			$amount_radwill = 0;
			$amount_safe = 0;
			$amount_short = 0;
			$amount_tuition = 0;
			$amount_upaasv = 0;

			$grand_total = 0;

			while ($MyResults = $MyValues -> fetch_assoc())
			{
				if($MyResults['LOAN_TYPE'] == "IM Student Loan")
				{
					$count_im++;
					$amount_im = $amount_im + $MyResults['LOAN_AMOUNT'];
				}

				else if($MyResults['LOAN_TYPE'] == "Radwill Loan")
				{
					$count_radwill++;
					$amount_radwill = $amount_radwill + $MyResults['LOAN_AMOUNT'];
				}

				else if($MyResults['LOAN_TYPE'] == "Safe Cash Loan")
				{
					$count_safe++;
					$amount_safe = $amount_safe + $MyResults['LOAN_AMOUNT'];
				}	

				else if($MyResults['LOAN_TYPE'] == "Short Term Loan")
				{
					$count_short++;
					$amount_short = $amount_short + $MyResults['LOAN_AMOUNT'];
				}	

				else if($MyResults['LOAN_TYPE'] == "Tuition Fee Loan")
				{
					$count_tuition++;
					$amount_tuition = $amount_tuition + $MyResults['LOAN_AMOUNT'];
				}

				else if($MyResults['LOAN_TYPE'] == "UPAASV Loan")
				{
					$count_upaasv++;
					$amount_upaasv = $amount_upaasv + $MyResults['LOAN_AMOUNT'];
				}

				$grand_total = $grand_total + $MyResults['LOAN_AMOUNT'];					
			}
		}

			
?>

<!DOCTYPE html>

<html>
	<!-- Page Contents -->

	<!-- Head -->
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
		<title>Search Results</title>
	</head>

	<!-- Body -->
	<body>
		<!-- Header -->
		<div class="gradient-overlay text-center bg-secondary p-1">
    		<div class="container-fluid p-1">
    			<div class="row">
    				<div class="col-md-12">
    					<div class="row">
    						<div class="col-md-2">
    							<img class="img-fluid d-block rounded-circle" src="uplogo.png" width="200" height="200">
    						</div>
    						<div class = "col-md-10">						
				             	<h1 class="text-white">
				                	<font color="#292b2c" class="text-white">
				                		<i>Office of the Student Financial Assistance<br></i>
				                	</font>
				              	</h1>

              					<h3 class="text-white">
                					<font color="#292b2c" class="text-white">
                						<i>Office of the Director for Student Affairs<br></i>
                					</font>
              					</h3>

              					<h4>
              						<i class="text-center text-white">University of the Philippines - Baguio<br></i>
              					</h4>
              					<h4>
              						<u class="text-center text-white">Student Loans<br></u>
              					</h4>
    						</div>
    					</div>
    				</div>
    			</div>
    		</div>
    	</div>

    	 <!-- Navigation Bar -->
	    <nav class="navbar navbar-expand-md navbar-dark bg-primary">
	    	<div class="container">

	    		<!-- Logo -->
	    		<a class="navbar-brand" href="index.php">
	    			<b>Home</b>
	    		</a>
	    		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    			<span class="navbar-toggler-icon"></span>
	    		</button>

	    		<!-- Links -->
				<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
	    			<ul class="navbar-nav">
			          	<li class="nav-item">
	    					<a class="nav-link" href="monthly_report.php"><i class="fa fa-calendar-o"></i>&nbsp;Monthly Reports</a>
			          	</li>

			          	<li class="nav-item">
	    					<a class="nav-link" href="<?php echo 'monthly_report_pdf.php?count_im='.$count_im.'&count_radwill='.$count_radwill.'&count_safe='.$count_safe.'&count_tuition='.$count_tuition.'&count_upaasv='.$count_upaasv.'&count_short='.$count_short.'&amount_im='.$amount_im.'&amount_radwill='.$amount_radwill.'&amount_safe='.$amount_safe.'&amount_tuition='.$amount_tuition.'&amount_upaasv='.$amount_upaasv.'&amount_short='.$amount_short.'&grand_total='.$grand_total.'&monthWord='.$monthWord.'&year='.$year.'&month='.$month_name.''?>"><i class="fa fa-file-pdf-o"></i>&nbsp;Export to PDF</a>
			          	</li>


			          	<li class="nav-item">
	    					<a class="nav-link" href="<?php echo 'monthly_report_csv.php?count_im='.$count_im.'&count_radwill='.$count_radwill.'&count_safe='.$count_safe.'&count_tuition='.$count_tuition.'&count_upaasv='.$count_upaasv.'&count_short='.$count_short.'&amount_im='.$amount_im.'&amount_radwill='.$amount_radwill.'&amount_safe='.$amount_safe.'&amount_tuition='.$amount_tuition.'&amount_upaasv='.$amount_upaasv.'&amount_short='.$amount_short.'&grand_total='.$grand_total.'&monthWord='.$monthWord.'&year='.$year.'&month='.$month_name.''?>"><i class="fa fa-file-excel-o"></i>&nbsp;Export to CSV</a>
			          	</li>
	          		</ul>
	       		</div>
	      	</div>
    	</nav>

    	<h1 class="jumbotron-fluid text-center py-4"><em>Monthly Reports</em></h1>
    	<h3 class="jumbotron-fluid text-center"><em><?php echo $monthWord.", ".$year;?></em></h3>
    	<h4 class="jumbotron-fluid text-center py-4">Finance Report</h3>
    	<?php

    		if ($MyValues -> num_rows > 0)
    		{
	    		echo "<div class=py-3> <div class=container> <div class=row>";
				$TableClass = "table";
	            echo "<table class =".$TableClass.">";
	            echo
	            "
	          	<thead>
	                <tr class = text-center>
	                	<th>Loan Type</th>
		                <th>Count of Beneficiaries</th>
						<th>Total Amount Given</th>
	                </tr>
	            </thead>
				";
	          
				echo '<tr>';
				echo '<td>IM Student Loan</td>';
				echo '<td> '.$count_im.' </td>';
				echo '<td> &#8369;'.$amount_im.' </td></tr>';

				echo '<tr>';
				echo '<td>Radwill Loan</td>';
				echo '<td> '.$count_radwill.' </td>';
				echo '<td> &#8369;'.$amount_radwill.' </td></tr>';

				echo '<tr>';
				echo '<td>Safe Cash Loan</td>';
				echo '<td> '.$count_safe.' </td>';
				echo '<td> &#8369;'.$amount_safe.' </td></tr>';

				echo '<tr>';
				echo '<td>Short Term Loan</td>';
				echo '<td> '.$count_short.' </td>';
				echo '<td> &#8369;'.$amount_short.' </td></tr>';

				echo '<tr>';
				echo '<td>Tuition Fee Loan</td>';
				echo '<td> '.$count_tuition.' </td>';
				echo '<td> &#8369;'.$amount_tuition.' </td></tr>';					
	            

	            echo '<tr>';
				echo '<td>UPAASV Loan</td>';
				echo '<td> '.$count_upaasv.' </td>';
				echo '<td> &#8369;'.$amount_upaasv.' </td></tr>';

	        	echo "</table></div></div></div>";

	        	echo '<h4 class="jumbotron-fluid text-center py-4">Grand Total: &#8369;'.$grand_total.'</h4>';
        	}

        	else
			{
				$EmptySearchResults = "Your search returned no matches.";
				$DivClass = "text-center py-5 jumbotron";
				echo "<div class = py-5><div class = ".$DivClass."><h3>".$EmptySearchResults."</h3></div></div>";
				}
			}
		?>

		<div class="container">
			<div class="dropdown-divider"></div>
			<div class="dropdown-divider"></div>
		</div>

		<h5 class="jumbotron-fluid text-center py-4">Student List</h5>
		<?php
        	$MySearchQuery = "SELECT * FROM STUDENT WHERE (MONTH(STUDENT.DATE_ADDED) = $month_name AND YEAR(STUDENT.DATE_ADDED) = $year)";
			$MyValues = $MyConnection -> query($MySearchQuery);

			if (($MyValues -> num_rows) > 0)
			{
				echo '
				<div class="py-3">
    				<div class="container">
		    			<div class="row">
		        			<div class="col-md-12">
 								<table class = "table">
     	 							<thead>
						            	<tr class = "text-center">
											<th>Academic Year</th>
											<th>Academic Semester</th>
											<th>Application Date</th>
											<th>Loan Type</th>
							                <th>Student Number</th>
											<th>Student Name</th>
											<th>Course</th>
											<th>Year</th>
											<th>Loan Amount</th>
											<th>Outstanding Balance</th>
						            	</tr>
		           					</thead>
		           					<tbody>
				';

				while ($MyResults = $MyValues -> fetch_assoc())
				{
					echo '<tr><td>'.$MyResults['LOAN_YEAR'].'</td>';
					echo '<td>'.$MyResults['LOAN_SEM'].'</td>';
					echo '<td>'.$MyResults['DATE_ADDED'].'</td>';
					echo '<td>'.$MyResults['LOAN_TYPE'].'</td>';
					echo '<td>'.$MyResults['STUD_NUM'].'</td>';
					echo '<td>'.$MyResults['STUD_NAME'].'</td>';
					echo '<td>'.$MyResults['STUD_COURSE'].'</td>';
					echo '<td>'.$MyResults['STUD_YEAR'].'</td>';
					echo '<td>&#8369;'.$MyResults['LOAN_AMOUNT'].'</td>';
					echo '<td>&#8369;'.$MyResults['OUT_BAL'].'</td>';
				}

				echo '</tbody></table></div></div></div></div>';
			}

			else
			{
				$EmptySearchResults = "The list is empty. Please add the appropriate student records.";
				$DivClass = "text-center py-5 jumbotron";
				echo "<div class = py-5><div class = ".$DivClass."><h3>".$EmptySearchResults."</h3></div></div>";
			}
		?>

		<script type="text/javascript">
			function deleteconfig()
			{
				var del = confirm('Are you sure you want to delete this?');
				if(del == true)
				{
					alert ("Successfully Deleted!");
				}

				return del;
			}
	    </script>
    	 <!-- Footer -->
        <div class = "text-md-center">
			<p>
				<a href = "monthly_report.php" title = "Let's go back!">&#8617; Go Back to the Monthly Report Search Page</a>
			</p>
		</div>

		<script src="scripts/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  		<script src="scripts/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
  		<script src="scripts/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    </body>

    <!-- Close Database Connection -->
    <?php
    	mysqli_close($MyConnection);
    ?>
</html>