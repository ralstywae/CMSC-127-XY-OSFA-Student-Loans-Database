<?php
	session_start();
	error_reporting(0);
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db_database = 'osfa_db';
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db_database);

	$monthNum = $_GET['month'];
	$monthWord = $_GET['monthWord'];
	$year = $_GET['year'];

	$query = mysqli_query($conn, "SELECT LOAN_YEAR, LOAN_SEM, LOAN_TYPE, STUD_NUM, STUD_NAME, STUD_YEAR, STUD_COURSE, STUD_ADDRESS, STUD_CONTACT, STUD_EMAIL, OUT_BAL FROM STUDENT WHERE (MONTH(STUDENT.DATE_ADDED) = $monthNum AND YEAR(STUDENT.DATE_ADDED) = $year) ORDER BY STUDENT.LOAN_TYPE AND STUDENT.DATE_ADDED");
	$resultData = array();

	for ($i=0;$i<mysqli_num_rows($query);$i++)
	{
		$result = mysqli_fetch_array($query);
		array_push($resultData, $result);
	}


	$count_im = $_GET['count_im'];
	$count_radwill = $_GET['count_radwill'];
	$count_safe = $_GET['count_safe'];
	$count_short = $_GET['count_short'];
	$count_tuition = $_GET['count_tuition'];
	$count_upaasv = $_GET['count_upaasv'];

	$amount_im = $_GET['amount_im'];
	$amount_radwill = $_GET['amount_radwill'];
	$amount_safe = $_GET['amount_safe'];
	$amount_short = $_GET['amount_short'];
	$amount_tuition = $_GET['amount_tuition'];
	$amount_upaasv = $_GET['amount_upaasv'];

	$grand_total = $_GET['grand_total'];
	$total_count = $count_im + $count_radwill + $count_safe + $count_short + $count_tuition + $count_upaasv;

	$monthWord = $_GET['monthWord'];
	$year = $_GET['year'];

	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename=Monthly-Report.csv');

	$output = fopen('php://output', 'w');

	fputcsv($output, array('MONTHLY REPORT'));
	fputcsv($output, array('Loan Type', 'Count of Beneficiaries', 'Total Amount Given'));
	fputcsv($output, array('IM Student Loan', $count_im, $amount_im));
	fputcsv($output, array('Radwill Loan', $count_radwill, $amount_radwill));
	fputcsv($output, array('Safe Cash Loan', $count_safe, $amount_safe));
	fputcsv($output, array('Short Term Loan', $count_short, $amount_short));
	fputcsv($output, array('Tuition Fee Loan', $count_tuition, $amount_tuition));
	fputcsv($output, array('UPAASV Loan', $count_upaasv, $amount_upaasv));
	fputcsv($output, array('Total', $total_count, $grand_total));

	fputcsv($output, array('','',''));
	fputcsv($output, array('Student List'));
	fputcsv($output, array('A.Y.', 'Sem', 'Loan Type', 'Stud Num', 'Student Name', 'Year', 'Course', 'Address', 'Contact Number', 'E-mail Address', 'Out Bal'));

	foreach ($resultData as $eachResult) 
	{
		fputcsv($output, array($eachResult['LOAN_YEAR'], $eachResult['LOAN_SEM'], $eachResult['LOAN_TYPE'],$eachResult['STUD_NUM'], $eachResult['STUD_NAME'], $eachResult['STUD_YEAR'], $eachResult['STUD_COURSE'], $eachResult['STUD_ADDRESS'], $eachResult['STUD_CONTACT'], $eachResult['STUD_EMAIL'], $eachResult['OUT_BAL']));
	}

	

	fclose($output);

?>