<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServerName = "localhost";
	$MyUserName = "root";
	$MyPassword = "";

	//Database
	$MyDBName = 'osfa_db';

	//Start Connection
	$MyConnection = mysqli_connect($MyServer, $MyUserName, $MyPassword, $MyDBName);

	$num = $_REQUEST['num'];
	$type = $_REQUEST['type'];
	
	mysqli_query($MyConnection, "DELETE FROM STUDENT where STUD_NUM = '$num' AND LOAN_TYPE = '$type'");
	
	mysqli_query($MyConnection, "DELETE FROM BAL_HIST where STUD_NUM = '$num' AND LOAN_TYPE = '$type'");
	
	header("Location: list.php?type=$type");
?>