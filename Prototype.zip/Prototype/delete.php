<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServerName = "localhost";
	$MyUserName = "root";
	$MyPassword = "";

	//Database
	$MyDBName = 'osfa_db';

	//Start Connection
	$MyConnection = mysql_connect($MyServer, $MyUserName, $MyPassword);

	//Select Database
	mysql_select_db($MyDBName,$MyConnection);

	$num=$_GET['num'];
	$type=$_GET['type'];
	
	mysql_query("DELETE FROM STUDENT where STUD_NUM = '$num' AND LOAN_TYPE = '$type'");
	
	header("Location: list.php?type=$type");
?>