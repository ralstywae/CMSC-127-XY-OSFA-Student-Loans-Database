<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServerName = "localhost";
	$MyUserName = "root";
	$MyPassword = "";

	//Database
	$MyDBName = 'osfa_db';

	//Start Connection
	$MyConnection = mysql_connect($MyServer, $MyUserName, $MyPassword);

	//Select Database
	mysql_select_db($MyDBName,$MyConnection);

	$type = $_GET['type'];

	if($_POST['save'])
	{
		$nsname = $_POST['sname'];
		$nadd = $_POST['address'];
		$nsex = $_POST['sex'];
		$ncollege = $_POST['college'];
		$nyear = $_POST['year'];
		$ncourse = $_POST['course'];
		$ncontact = $_POST['contact'];
		$nemail = $_POST['email'];
		$nsnum = $_POST['snum'];

		$ntype = $type;
		$nacadyr = $_POST['acadyr'];
		$nsem = $_POST['sem'];
		$namt_borrowed = $_POST['amt_borrowed'];
		$namt_paid = $_POST['amt_paid'];
		$ndate_paid = $_POST['date_paid'];
		$nor_num = $_POST['or_num'];
		$nreason = $_POST['reason'];

		if(empty($namt_paid))
		{
			$namt_paid = 0;
		}

		if(empty($ndate_paid))
		{
			$ndate_paid = 0;
		}

		if(empty($nor_num))
		{
			$nor_num = 0;
		}

		mysql_query("INSERT INTO STUDENT (STUD_NAME, STUD_ADDRESS, STUD_SEX, STUD_COLLEGE, STUD_YEAR, STUD_COURSE, STUD_CONTACT, STUD_EMAIL, STUD_NUM, LOAN_TYPE, LOAN_YEAR, LOAN_SEM, LOAN_AMOUNT, REASON)
		VALUES ('$nsname','$nadd', '$nsex', '$ncollege', $nyear, '$ncourse', $ncontact, '$nemail', '$nsnum', '$ntype', $nacadyr, '$nsem', $namt_borrowed, '$nreason');");

		mysql_query("INSERT INTO BAL_HIST (LOAN_TYPE, AMT_BORROWED, AMT_PAID, DATE_PAID, OR_NUM, STUD_NUM)
		VALUES ('$ntype', $namt_borrowed, $namt_paid, '$ndate_paid', $nor_num, '$nsnum');");

		echo "<script>alert('Added Successfully!');
			location = 'list.php?type=$type';</script>";
	}
?>

<!DOCTYPE html>
<html>
	<!-- Head -->
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
  		<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
  		<link rel="stylesheet" href="css/bootstrap.css" type="text/css">
		<title>Add Student Information</title>
	</head>

	<!-- Body -->
	<body>
		<!-- Header -->
		<div class="gradient-overlay text-center bg-secondary p-1">
	    	<div class="container-fluid p-1">
	    		<div class="row">
	    			<div class="col-md-12">
	    				<div class="row">
	    					<div class="col-md-2">
	    						<img class="img-fluid d-block rounded-circle" src="uplogo.png" width="200" height="200">
	    					</div>

	    					<div class="col-md-10">
    							<h1 class="text-white">
				                	<font color="#292b2c" class="text-white">
				                		<i>Office of the Student Financial Assistance<br></i>
				                	</font>
				              	</h1>

              					<h3 class="text-white">
                					<font color="#292b2c" class="text-white">
                						<i>Office of the Director for Student Affairs<br></i>
                					</font>
              					</h3>

              					<h4>
              						<i class="text-center text-white">University of the Philippines - Baguio<br></i>
              					</h4>
              					<h4>
              						<u class="text-center text-white">Student Loans<br></u>
              					</h4>
	    					</div>
	    				</div>
	    			</div>
	    		</div>
	    	</div>
	    </div>

	    <!-- Navigation Bar -->
	    <nav class="navbar navbar-expand-md navbar-dark bg-primary">
	    	<div class="container">

	    		<!-- Logo -->
	    		<a class="navbar-brand" href="index.php">
	    			<b>Home</b>
	    		</a>
	    		<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent" aria-controls="navbar2SupportedContent" aria-expanded="false" aria-label="Toggle navigation">
	    			<span class="navbar-toggler-icon"></span>
	    		</button>

	    		<!-- Links -->
	    		<div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
					<ul class="navbar-nav">
						<li class="nav-item">
							<a class="nav-link" href="search.php"><i class="fa d-inline fa-lg fa-search"></i>Search</a>
						</li>
					</ul>
	       		</div>
	      	</div>
    	</nav>

    	<!-- Addition Form -->
    	<div class="py-5">
  			<div class="container">
    			<div class="row">
      				<div class="col-md-12">
        				<?php echo '<h1>'.$type.'</h1>'; ?>
        				<br>
      				</div>
    			</div>
   				<form class="form-signin" name="myForm" method="POST" enctype="multipart/form-data" name="addroom" onsubmit="return validateForm()">
      				<div class="row px-5">
      					<label for="example-search-input" class="col-2 col-form-label">Year of Application</label>
        				<div class="row">
							<div class="btn-group px-4">
								<select name="acadyr">
									<option value="2015-2016">2015-2016</option>
									<option value="2016-2017">2016-2017</option>
									<option value="2017-2018">2017-2018</option>
									<option value="2018-2019">2018-2019</option>
									<option value="2019-2020">2019-2020</option>
								</select>
							<div class="btn-group px-3">
								<select name="sem">
									<option value="1st">1st Semester</option>
									<option value="2nd">2nd Semester</option>
									<option value="sum">Summer/Midyear</option>
								</select>
							</div>
						</div>
      				</div>

					<div class="container py-2">
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Student Name</label>
							<div class="col-10 col-md-6">
								<input class="form-control" id="snumber-input" name="sname" required placeholder="Last Name, First Name M.I.">
							</div>

							<label for="example-number-input" class="py-2 form-label">Student Number</label>
							<div class="col">
								<input class="form-control" id="snumber-input" name="snum" required pattern ="\d{4}[-]\d{5}" placeholder="XXXX-XXXXX">
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Course</label>
							<div class="col-10 col-md-6">
								<input class="form-control" id="snumber-input" name="course" required placeholder="Undergraduate Degree/Graduate Degree">
							</div>
							<label for="example-search-input" class="form-label py-2">Sex</label>
							<div class="px-2 py-2">
								<select name="sex" required>
									<option value="Male">Male</option>
									<option value="Female">Female</option>
								</select>
							</div>
							<label for="example-number-input" class="form-label py-2">Year</label>
							<div class="px-2 py-2">
								<select name="year">
									<option value = 1>1st Year</option>
									<option value = 2>2nd Year</option>
									<option value = 3>3rd Year</option>
									<option value = 4>4th Year</option>
								</select>
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Mailing/Provincial Address</label>
							<div class="col-10 col-md-10">
								<input class="form-control" id="snumber-input" name="address" required placeholder="#69 Example Street, Null City, Nullcline Island">
							</div>
						</div>
						<div class="form-group row">
						<label for="example-number-input" class="col-2 col-form-label">E-mail Address</label>
						<div class="col-10 col-md-10">
							<input class="form-control" type="email" id="email-input" name="email" required placeholder="example@some.com"> </div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Telephone/Cellphone Number</label>
							<div class="col-10 col-md-10">
								<input class="form-control" id="telnum-input" name="contact" required pattern="\d{,11}" placeholder="Max: 11-Digit #">
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Amount Borrowed</label>
							<div class="col-10 col-md-6">
								<input class="form-control" id="snumber-input" name="amt_borrowed" required pattern="\d{,5}" placeholder="Max: 5-Digit #">
							</div>
							<label for="example-number-input" class="col-2 col-form-label">Amount Paid</label>
							<div class="col-10 col-md-2">
								<input class="form-control" id="snumber-input" name="amt_paid" placeholder="Max: 5-Digit #">
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Date Paid</label>
							<div class="col-10 col-md-6">
								<input class="form-control" id="snumber-input" name="date_paid" pattern="\d{4}-\{2}-\{2}" placeholder="YYYY-MM-DD"> 
							</div>
							<label for="example-number-input" class="col-2 col-form-label">O.R. No.</label>
							<div class="col-10 col-md-2">
								<input class="form-control" id="snumber-input" name="or_num" pattern="\d{10}" placeholder="10-Digit #">
							</div>
						</div>
						<div class="form-group row">
							<label for="example-number-input" class="col-2 col-form-label">Reason/s</label>
        					<div class="col-10">
        						<textarea class="form-control" id="exampleTextarea" rows="3" name="reason" required pattern = "/^[0-9A-Za-z!@.,;:'"?-]{1,200}\z/" placeholder="200 Characters Only"></textarea>
        					</div>
        				</div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<div class="container">
								<div class="row">
									<div class="col-md-12 center">
										<center>
											<button class="btn" type="submit" name="save" value="save" id="button1" style="background-color: #C0C0C0; width: 150px; height: 60px; padding: 5px"><span>Save</span>
											</button>
										</center>
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>

		<!-- Scripts -->
		<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.11.0/umd/popper.min.js" integrity="sha384-b/U6ypiBEHpOf/4+1nzFpr53nxSS+GLCkfwBdFNTxtclqqenISfwAzpKaMNFNmj4" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-beta/js/bootstrap.min.js" integrity="sha384-h0AbiXch4ZDo7tp9hKZ4TsHbi047NrKGLO3SEJAg45jXxnGIfYzk4Si90RDIqNm1" crossorigin="anonymous"></script>
    </body>
</html>