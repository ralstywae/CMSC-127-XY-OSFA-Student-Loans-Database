<?php
	//error_reporting(0);
	require('cellfit.php');
	$d=date('d_m_Y');

	$header=array('A.Y.', 'SEMESTER', 'APPLICATION DATE', 'LOAN TYPE', 'AMOUNT BORROWED', 'AMOUNT PAID', 'DATE PAID', 'O.R. NUMBER', 'BALANCE', 'REMARKS');

	$num = $_GET['num'];
	$name = $_GET['name'];

	//*** Load MySQL Data ***//
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db_database = 'osfa_db';

	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db_database);

	$query = mysqli_query($conn, "SELECT * FROM BAL_HIST WHERE STUD_NUM = '$num' ORDER BY DATE_ADDED");
	$resultData = array();

	for ($i=0;$i<mysqli_num_rows($query);$i++)
	{
		$result = mysqli_fetch_array($query);
		array_push($resultData, $result);
	}

	$pdf=new FPDF_CellFit();
	$pdf->AddPage("L");

	$pdf->SetFont('Helvetica','',20);
	$pdf->Ln();
	$pdf->Write(5, 'Transaction History:');
	$pdf->Ln();
	$pdf->Ln();
	$pdf->Write(5, $name);
	$pdf->Ln();
	$pdf->Ln();
	$pdf->Write(5, $num);
	$pdf->Ln();
	$pdf->Ln();
	$result = mysqli_query($conn, "select date_format(now(), '%W, %M %d, %Y') as date");

	while($row = mysqli_fetch_array($result))
	{
		$pdf->Write(5,$row['date']);
	}
	$pdf->Ln();
	$pdf->SetFontSize(10);

	$pdf->Ln();

	$pdf->Ln(5);
	$pdf->Ln(5);

	$pdf->Ln(0);
	$pdf->SetFillColor(255,255,255);
	$w = array(20,20,40,30,30,30,30,30,20,30);
	//Header
	$pdf->SetFont('Arial','B',9);

	for($i=0;$i<count($header);$i++)
	{
		$pdf->CellFitScale($w[$i],8,$header[$i],1,0,'C',1);
	}

	$pdf->SetFont('Arial','',9);
	foreach ($resultData as $eachResult) 
	{	
		$pdf->Ln();
		$pdf->CellFitScale(20,8,$eachResult['LOAN_YEAR'],1,0,'C',1);
		$pdf->CellFitScale(20,8,$eachResult['LOAN_SEM'],1, 0,'C',1);
		$pdf->CellFitScale(40,8,$eachResult['DATE_ADDED'],1,0,'C',1);
		$pdf->CellFitScale(30,8,$eachResult['LOAN_TYPE'],1,0,'C',1);
		$pdf->CellFitScale(30,8,$eachResult['AMT_BORROWED'],1,0,'C',1);
		$pdf->CellFitScale(30,8,$eachResult['AMT_PAID'],1,0,'C',1);
		if (empty($eachResult['DATE_PAID']) && empty($eachResult['OR_NUM']))
		{
			$pdf->CellFitScale(30,8,"NULL",1,0,'C',1);
			$pdf->CellFitScale(30,8,"NULL",1,0,'C',1);
		}

		else
		{
			$pdf->CellFitScale(30,8,$eachResult['DATE_PAID'],1,0,'C',1);
			$pdf->CellFitScale(30,8,$eachResult['OR_NUM'],1,0,'C',1);
		}

		$pdf->CellFitScale(20,8,$eachResult['OUT_BAL'],1,0,'C',1);
		$pdf->CellFitScale(30,8,$eachResult['PAYMENT_REMARKS'],1,0,'C',1);	
	}

	ob_end_clean();
	$pdf->Output();
?>