<?php
	session_start();
	error_reporting(0);
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db_database = 'osfa_db';
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db_database);

	$type = $_GET['type'];

	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename=Master-List.csv');

	$output = fopen('php://output', 'w');

	fputcsv($output, array('MASTER LIST'));
	fputcsv($output, array('Academic Year', 'Academic Semester', 'Loan Type', 'Student Number', 'Student Name', 'Year', 'Course', 'Address', 'Contact Number', 'E-mail Address', 'Outstanding Balance'));

	$query = mysqli_query($conn, "SELECT LOAN_YEAR, LOAN_SEM, LOAN_TYPE, STUD_NUM, STUD_NAME, STUD_YEAR, STUD_COURSE, STUD_ADDRESS, STUD_CONTACT, STUD_EMAIL, OUT_BAL FROM STUDENT natural join BAL_HIST");
	while($result = mysqli_fetch_assoc($query)){
		fputcsv($output, $result);
	}
?>