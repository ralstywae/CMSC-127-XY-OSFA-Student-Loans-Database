<?php
	session_start();
	error_reporting(0);
	
	//Server Credentials
	$MyServerName = "localhost";
	$MyUserName = "root";
	$MyPassword = "";

	//Database
	$MyDBName = 'osfa_db';

	//Start Connection
	$MyConnection = mysqli_connect($MyServer, $MyUserName, $MyPassword, $MyDBName);

	$num = $_GET['num'];
	$type = $_GET['type'];
	$sem = $_GET['sem'];
	$year = $_GET['year'];
	$added = $_GET['added'];
	

	$MySearchQuery = "SELECT * FROM STUDENT WHERE (STUDENT.STUD_NUM = '$num' AND STUDENT.LOAN_TYPE = '$type' AND STUDENT.LOAN_YEAR = '$year' AND STUDENT.LOAN_SEM = '$sem' AND STUDENT.DATE_ADDED = '$added')";
	
	$MyValues = $MyConnection -> query($MySearchQuery);

	if (($MyValues -> num_rows) > 0)
	{
		while ($MyResults = $MyValues -> fetch_assoc())
		{
			$sname = $MyResults['STUD_NAME'];
			$snum = $MyResults['STUD_NUM'];
			$sex =  $MyResults['STUD_SEX'];
			$address = $MyResults['STUD_ADDRESS'];
			$college =$MyResults['STUD_COLLEGE'];
			$syear = $MyResults['STUD_YEAR'];
			$course = $MyResults['STUD_COURSE'];
			$contact = $MyResults['STUD_CONTACT'];
			$email = $MyResults['STUD_EMAIL'];
			$amt_borrowed =  $MyResults['LOAN_AMOUNT'];
			$reason = $MyResults['REASON'];
			$out_bal = $MyResults['OUT_BAL'];
		}
	}

	mysqli_query($MyConnection, "INSERT INTO DATA_ARCHIVE (STUD_NAME, STUD_ADDRESS, STUD_SEX, STUD_COLLEGE, STUD_YEAR, STUD_COURSE, STUD_CONTACT, STUD_EMAIL, STUD_NUM, LOAN_TYPE, LOAN_YEAR, LOAN_SEM, LOAN_AMOUNT, OUT_BAL, REASON, DATE_ADDED) VALUES ('$sname','$address', '$sex', '$college', '$syear', '$course', '$contact', '$email', '$snum', '$type', '$year', '$sem', $amt_borrowed, $out_bal,'$reason', '$added');");

	mysqli_query($MyConnection, "DELETE FROM STUDENT WHERE (STUDENT.STUD_NUM = '$num' AND STUDENT.LOAN_TYPE = '$type' AND STUDENT.LOAN_YEAR = '$year' AND STUDENT.LOAN_SEM = '$sem' AND STUDENT.DATE_ADDED = '$added')");
	
	//mysqli_query($MyConnection, "DELETE FROM BAL_HIST where (STUDENT.STUD_NUM = '$num' AND STUDENT.LOAN_TYPE = '$type' AND STUDENT.LOAN_YEAR = '$year' AND STUDENT.LOAN_SEM = '$sem'");
	
	header("Location: list.php?type=$type");
?>