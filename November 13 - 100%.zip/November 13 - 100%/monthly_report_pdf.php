<?php
	//error_reporting(0);
	require('cellfit.php');
	$d=date('d_m_Y');

	$header=array('LOAN TYPE', 'COUNT OF BENEFICIARIES', 'TOTAL AMOUNT GIVEN');

	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db_database = 'osfa_db';
	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db_database);
	$query = mysqli_query($conn, "SELECT LOAN_YEAR, LOAN_SEM, LOAN_TYPE, STUD_NUM, STUD_NAME, STUD_YEAR, STUD_COURSE, STUD_ADDRESS, STUD_CONTACT, STUD_EMAIL, OUT_BAL FROM STUDENT");
	$resultData = array();

	for ($i=0;$i<mysqli_num_rows($query);$i++)
	{
		$result = mysqli_fetch_array($query);
		array_push($resultData,$result);
	}

	$count_im = $_GET['count_im'];
	$count_radwill = $_GET['count_radwill'];
	$count_safe = $_GET['count_safe'];
	$count_short = $_GET['count_short'];
	$count_tuition = $_GET['count_tuition'];
	$count_upaasv = $_GET['count_upaasv'];

	$amount_im = $_GET['amount_im'];
	$amount_radwill = $_GET['amount_radwill'];
	$amount_safe = $_GET['amount_safe'];
	$amount_short = $_GET['amount_short'];
	$amount_tuition = $_GET['amount_tuition'];
	$amount_upaasv = $_GET['amount_upaasv'];

	$grand_total = $_GET['grand_total'];

	$monthWord = $_GET['monthWord'];
	$year = $_GET['year'];

	$total_count = $count_im + $count_radwill + $count_safe + $count_short + $count_tuition + $count_upaasv;

	$pdf=new FPDF_CellFit();
	$pdf->AddPage("L");

	$pdf->SetFont('Helvetica','',20);
	$pdf->Ln();
	$pdf->Cell(80);
	$pdf->Write(5, 'Monthly Report for: ');
	$pdf->Write(5, $monthWord);
	$pdf->Write(5, ' ');
	$pdf->Write(5, $year);
	$pdf->Ln();
	$pdf->Ln();
	$pdf->Cell(110);
	$pdf->SetFont('Helvetica','',10);
	$result = mysqli_query($conn, "select date_format(now(), '%W, %M %d, %Y') as date");

	while($row = mysqli_fetch_array($result))
	{
		$pdf->Write(5,$row['date']);
	}

	$pdf->Cell(120);
	$pdf->SetFontSize(10);

	$pdf->Ln();

	$pdf->Ln(5);
	$pdf->Ln(5);

	$pdf->Ln(0);
	$pdf->SetFillColor(255,255,255);
	$w = array(140,60,70);
	//Header
	$pdf->SetFont('Arial','B',9);
	for($i=0;$i<count($header);$i++)
	{
		$pdf->CellFitScale($w[$i],8,$header[$i],1,0,'C',1);
	}
	
	$pdf->Ln();
	$pdf->SetFont('Arial','',9);

	$pdf->CellFitScale(140,8,'IM Student Loan',1,0,'C',1);
	$pdf->CellFitScale(60,8,$count_im,1, 0,'C',1);
	$pdf->CellFitScale(70,8,$amount_im,1, 0,'C',1);
	$pdf->Ln();

	$pdf->CellFitScale(140,8,'Radwill Loan',1,0,'C',1);
	$pdf->CellFitScale(60,8,$count_radwill,1, 0,'C',1);
	$pdf->CellFitScale(70,8,$amount_radwill,1, 0,'C',1);
	$pdf->Ln();

	$pdf->CellFitScale(140,8,'Safe Cash Loan',1,0,'C',1);
	$pdf->CellFitScale(60,8,$count_safe,1, 0,'C',1);
	$pdf->CellFitScale(70,8,$amount_safe,1, 0,'C',1);
	$pdf->Ln();

	$pdf->CellFitScale(140,8,'Short Term Loan',1,0,'C',1);
	$pdf->CellFitScale(60,8,$count_short,1, 0,'C',1);
	$pdf->CellFitScale(70,8,$amount_short,1, 0,'C',1);
	$pdf->Ln();

	$pdf->CellFitScale(140,8,'Tuition Fee Loan',1,0,'C',1);
	$pdf->CellFitScale(60,8,$count_tuition,1, 0,'C',1);
	$pdf->CellFitScale(70,8,$amount_tuition,1, 0,'C',1);
	$pdf->Ln();

	$pdf->CellFitScale(140,8,'UPAASV Loan',1,0,'C',1);
	$pdf->CellFitScale(60,8,$count_upaasv,1, 0,'C',1);
	$pdf->CellFitScale(70,8,$amount_tuition,1, 0,'C',1);
	$pdf->Ln();

	$pdf->Ln();
	$pdf->SetFont('Arial','B',10);
	$pdf->CellFitScale(140,8,'GRAND TOTAL',1,0,'C',1);
	$pdf->CellFitScale(60,8,$total_count,1, 0,'C',1);
	$pdf->CellFitScale(70,8,$grand_total,1, 0,'C',1);
	$pdf->Ln();	

	$pdf->AddPage("L");
	$header=array('A.Y.', 'Sem', 'Loan Type', 'Stud Num', 'Student Name', 'Year', 'Course', 'Address', 'Contact Number', 'E-mail Address', 'Out Bal');
	$pdf->SetFont('Helvetica','',14);
	$pdf->Cell(5);
	$pdf->Write(5, $id);
	$pdf->Ln();
	$pdf->Cell(5);
	$pdf->Write(5, 'Student List for '.$monthWord.' '.$year);
	$pdf->Ln();
	$pdf->SetFontSize(8);
	$pdf->Ln();

	$pdf->Ln(5);

	$pdf->Ln(0);
	//$pdf->BasicTable($header,$resultData);
	$pdf->SetFillColor(255,255,255);
	//$this->SetDrawColor(255, 0, 0);
	$w=array(20,10,30,20,45,10,30,45,25,30,15);
	
	//Header
	$pdf->SetFont('Arial','B',9);
	for($i=0;$i<count($header);$i++)
	{
		$pdf->CellFitScale($w[$i],8,$header[$i],1,0,'C',1);
	}
	$pdf->Ln();
	
	//Data
	$pdf->SetFont('Arial','',9);
	foreach ($resultData as $eachResult) 
	{
		$pdf->CellFitScale(20,8,$eachResult['LOAN_YEAR'],1,0,'C',1);
		$pdf->CellFitScale(10,8,$eachResult['LOAN_SEM'],1, 0,'C',1);
		$pdf->CellFitScale(30,8,$eachResult['LOAN_TYPE'],1,0,'C',1);
		$pdf->CellFitScale(20,8,$eachResult['STUD_NUM'],1,0,'C',1);
		$pdf->CellFitScale(45,8,$eachResult['STUD_NAME'],1,0,'C',1);
		$pdf->CellFitScale(10,8,$eachResult['STUD_YEAR'],1,0,'C',1);
		$pdf->CellFitScale(30,8,$eachResult['STUD_COURSE'],1,0,'C',1);
		$pdf->CellFitScale(45,8,$eachResult['STUD_ADDRESS'],1,0,'C',1);
		$pdf->CellFitScale(25,8,$eachResult['STUD_CONTACT'],1,0,'C',1);
		$pdf->CellFitScale(30,8,$eachResult['STUD_EMAIL'],1,0,'C',1);
		$pdf->CellFitScale(15,8,$eachResult['OUT_BAL'],1,0,'C',1);
		$pdf->Ln();
		 	 	 	 	
	}
	ob_end_clean();
	$pdf->Output();
?>