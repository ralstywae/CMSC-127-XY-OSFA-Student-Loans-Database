<?php
    require('fpdf.php');

    class PDF extends FPDF
    {
        function ImprovedTable($header, $data)
        {
            // Column widths
            $w = array();
            for ($i=0; $i < count($header); $i++)
            { 
                array_push($w, 85);
            }
            // Header
            for($i=0;$i<count($header);$i++)
            {
                $this->Cell($w[$i],7,$header[$i],1,0,'C');
            }
            $this->Ln();
            // Data
            foreach($data as $row)
            {
                for($i=0;$i<count($header);$i++)
                {
                    $this->Cell($w[$i], 'C');
                }

                $this->Ln();
            }
            // Closing line
            $this->Cell(array_sum($w),0,'','T');
        }
    }
?>