<?php
//error_reporting(0);
require('cellfit.php');
$d=date('d_m_Y');

$header=array('LOAN TYPE', 'COUNT OF BENEFICIARIES', 'TOTAL AMOUNT GIVEN');
//Data loading
//*** Load MySQL Data ***//
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db_database = 'osfa_db';
	$conn = mysql_connect($dbhost, $dbuser, $dbpass);
	mysql_select_db($db_database,$conn);

	$count_im = $_GET['count_im'];
	$count_radwill = $_GET['count_radwill'];
	$count_safe = $_GET['count_safe'];
	$count_short = $_GET['count_short'];
	$count_tuition = $_GET['count_tuition'];
	$count_upaasv = $_GET['count_upaasv'];

	$amount_im = $_GET['amount_im'];
	$amount_radwill = $_GET['amount_radwill'];
	$amount_safe = $_GET['amount_safe'];
	$amount_short = $_GET['amount_short'];
	$amount_tuition = $_GET['amount_tuition'];
	$amount_upaasv = $_GET['amount_upaasv'];

	$grand_total = $_GET['grand_total'];

	$monthWord = $_GET['monthWord'];
	$year = $_GET['year'];

	$query = mysql_query("SELECT LOAN_TYPE FROM STUDENT");
	$resultData = array();
	for ($i = 0; $i < mysql_num_rows($query); $i++) {
		$result = mysql_fetch_array($query);
		array_push($resultData,$result);
	}

	$total_count = $count_im + $count_radwill + $count_safe + $count_short + $count_tuition + $count_upaasv;

//************************//


$pdf=new FPDF_CellFit();
$pdf->AddPage("L");

	$pdf->SetFont('Helvetica','',20);
	$pdf->Ln();
	$pdf->Cell(80);
	$pdf->Write(5, 'Monthly Report for: ');
	$pdf->Write(5, $monthWord);
	$pdf->Write(5, ' ');
	$pdf->Write(5, $year);
	$pdf->Ln();

	$pdf->Cell(120);
	$pdf->SetFontSize(10);
	$result=mysql_query("select date_format(now(), '%W, %M %d, %Y') as date");
	while( $row=mysql_fetch_array($result) )
	{
		$pdf->Write(5,$row['date']);
	}
	$pdf->Ln();

	$pdf->Ln(5);
	$pdf->Ln(5);

$pdf->Ln(0);
//$pdf->BasicTable($header,$resultData);
$pdf->SetFillColor(255,255,255);
//$this->SetDrawColor(255, 0, 0);
$w=array(140,60,70);
	
	//Header
	$pdf->SetFont('Arial','B',9);
	for($i=0;$i<count($header);$i++)
		$pdf->CellFitScale($w[$i],8,$header[$i],1,0,'C',1);
	$pdf->Ln();
	
	//Data
	$pdf->SetFont('Arial','',9);
	//foreach ($resultData as $eachResult) 
	//{
		$pdf->CellFitScale(140,8,'IM Student Loan',1,0,'C',1);
		$pdf->CellFitScale(60,8,$count_im,1, 0,'C',1);
		$pdf->CellFitScale(70,8,$amount_im,1, 0,'C',1);
		$pdf->Ln();

		$pdf->CellFitScale(140,8,'Radwill Loan',1,0,'C',1);
		$pdf->CellFitScale(60,8,$count_radwill,1, 0,'C',1);
		$pdf->CellFitScale(70,8,$amount_radwill,1, 0,'C',1);
		$pdf->Ln();

		$pdf->CellFitScale(140,8,'Safe Cash Loan',1,0,'C',1);
		$pdf->CellFitScale(60,8,$count_radwill,1, 0,'C',1);
		$pdf->CellFitScale(70,8,$amount_radwill,1, 0,'C',1);
		$pdf->Ln();

		$pdf->CellFitScale(140,8,'Short Term Loan',1,0,'C',1);
		$pdf->CellFitScale(60,8,$count_short,1, 0,'C',1);
		$pdf->CellFitScale(70,8,$amount_short,1, 0,'C',1);
		$pdf->Ln();

		$pdf->CellFitScale(140,8,'Tuition Fee Loan',1,0,'C',1);
		$pdf->CellFitScale(60,8,$count_tuition,1, 0,'C',1);
		$pdf->CellFitScale(70,8,$amount_tuition,1, 0,'C',1);
		$pdf->Ln();

		$pdf->CellFitScale(140,8,'UPAASV Loan',1,0,'C',1);
		$pdf->CellFitScale(60,8,$count_upaasv,1, 0,'C',1);
		$pdf->CellFitScale(70,8,$amount_tuition,1, 0,'C',1);
		$pdf->Ln();

		$pdf->CellFitScale(270,8,'',1, 0,'C',1);
		$pdf->Ln();

		$pdf->CellFitScale(140,8,'GRAND TOTAL',1,0,'C',1);
		$pdf->CellFitScale(60,8,$total_count,1, 0,'C',1);
		$pdf->CellFitScale(70,8,$grand_total,1, 0,'C',1);
		$pdf->Ln();	
	//}
	ob_end_clean();
	$pdf->Output();
?>