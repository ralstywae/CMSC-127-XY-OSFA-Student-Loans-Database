<?php

	$header=array('A.Y.', 'SEMESTER', 'APPLICATION DATE', 'LOAN TYPE', 'AMOUNT BORROWED', 'AMOUNT PAID', 'DATE PAID', 'O.R. NUMBER', 'BALANCE', 'REMARKS');

	$num = $_GET['num'];
	$name = $_GET['name'];

	//*** Load MySQL Data ***//
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$db_database = 'osfa_db';

	$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db_database);

	$query = mysqli_query($conn, "SELECT * FROM BAL_HIST WHERE STUD_NUM = '$num' ORDER BY DATE_ADDED");
	$resultData = array();
	for ($i=0;$i<mysqli_num_rows($query);$i++)
	{
		$result = mysqli_fetch_array($query);
		array_push($resultData, $result);
	}

	$output = fopen('php://output', 'w');

	header('Content-Type: text/csv; charset=utf-8');
	header('Content-Disposition: attachment; filename='.$num.'_HISTORY.csv');

	fputcsv($output, array($name, $num));
	fputcsv($output, $header);
	foreach ($resultData as $eachResult) 
	{	
		fputcsv($output, array($eachResult['LOAN_YEAR'], $eachResult['LOAN_SEM'], $eachResult['DATE_ADDED'], $eachResult['LOAN_TYPE'], $eachResult['LOAN_AMOUNT'], $eachResult['AMT_PAID'], $eachResult['DATE_PAID'], $eachResult['OR_NUM'], $eachResult['OUT_BAL'], $eachResult['PAYMENT_REMARKS']));
	}

	fclose($output);

?>